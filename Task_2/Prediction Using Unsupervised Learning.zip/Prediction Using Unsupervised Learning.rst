2: PREDICTION USING UNSUPERVISED LEARNING
=========================================

The Iris flower data set or Fisher’s Iris data set is a multivariate data set introduced by the British statistician, eugenicist, and biologist Ronald Fisher in his 1936 paper.The data set consists of 50 samples from each of three species of Iris (Iris setosa, Iris virginica and Iris versicolor). Four features were measured from each sample: the length and the width of the sepals and petals, in centimeters. Based on the combination of these four features, Fisher developed a linear discriminant model to distinguish the species from each other.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    

OVERVIEW: From the given ‘Iris’ dataset, predict the optimum number of clusters and represent it visually.
----------------------------------------------------------------------------------------------------------

ATTRIBUTES
~~~~~~~~~~

sepal length in cm
^^^^^^^^^^^^^^^^^^

sepal width in cm
^^^^^^^^^^^^^^^^^

petal length in cm
^^^^^^^^^^^^^^^^^^

petal width in cm
^^^^^^^^^^^^^^^^^

class: – Iris Setosa – Iris Versicolour – Iris Virginica
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

STEP I: IMPORTING THE REQUIRED LIBRARIES AND LOADING THE IRIS DATASET/CSV FILE
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    # Importing the libraries
    import numpy as np
    import matplotlib.pyplot as plt
    import pandas as pd
    import seaborn as sns
    from sklearn import datasets

.. code:: ipython3

    iris=pd.read_csv("iris.csv")
    iris.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Id</th>
          <th>SepalLengthCm</th>
          <th>SepalWidthCm</th>
          <th>PetalLengthCm</th>
          <th>PetalWidthCm</th>
          <th>Species</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1</td>
          <td>5.1</td>
          <td>3.5</td>
          <td>1.4</td>
          <td>0.2</td>
          <td>Iris-setosa</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2</td>
          <td>4.9</td>
          <td>3.0</td>
          <td>1.4</td>
          <td>0.2</td>
          <td>Iris-setosa</td>
        </tr>
        <tr>
          <th>2</th>
          <td>3</td>
          <td>4.7</td>
          <td>3.2</td>
          <td>1.3</td>
          <td>0.2</td>
          <td>Iris-setosa</td>
        </tr>
        <tr>
          <th>3</th>
          <td>4</td>
          <td>4.6</td>
          <td>3.1</td>
          <td>1.5</td>
          <td>0.2</td>
          <td>Iris-setosa</td>
        </tr>
        <tr>
          <th>4</th>
          <td>5</td>
          <td>5.0</td>
          <td>3.6</td>
          <td>1.4</td>
          <td>0.2</td>
          <td>Iris-setosa</td>
        </tr>
      </tbody>
    </table>
    </div>



STEP II: SPLITTING THE DATASET INTO CATEGORICAL AND CONTINUOUS DATASET
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    categorical=['Species']
    continuous=['Id','SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm']

.. code:: ipython3

    iris[continuous].describe()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Id</th>
          <th>SepalLengthCm</th>
          <th>SepalWidthCm</th>
          <th>PetalLengthCm</th>
          <th>PetalWidthCm</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>count</th>
          <td>150.000000</td>
          <td>150.000000</td>
          <td>150.000000</td>
          <td>150.000000</td>
          <td>150.000000</td>
        </tr>
        <tr>
          <th>mean</th>
          <td>75.500000</td>
          <td>5.843333</td>
          <td>3.054000</td>
          <td>3.758667</td>
          <td>1.198667</td>
        </tr>
        <tr>
          <th>std</th>
          <td>43.445368</td>
          <td>0.828066</td>
          <td>0.433594</td>
          <td>1.764420</td>
          <td>0.763161</td>
        </tr>
        <tr>
          <th>min</th>
          <td>1.000000</td>
          <td>4.300000</td>
          <td>2.000000</td>
          <td>1.000000</td>
          <td>0.100000</td>
        </tr>
        <tr>
          <th>25%</th>
          <td>38.250000</td>
          <td>5.100000</td>
          <td>2.800000</td>
          <td>1.600000</td>
          <td>0.300000</td>
        </tr>
        <tr>
          <th>50%</th>
          <td>75.500000</td>
          <td>5.800000</td>
          <td>3.000000</td>
          <td>4.350000</td>
          <td>1.300000</td>
        </tr>
        <tr>
          <th>75%</th>
          <td>112.750000</td>
          <td>6.400000</td>
          <td>3.300000</td>
          <td>5.100000</td>
          <td>1.800000</td>
        </tr>
        <tr>
          <th>max</th>
          <td>150.000000</td>
          <td>7.900000</td>
          <td>4.400000</td>
          <td>6.900000</td>
          <td>2.500000</td>
        </tr>
      </tbody>
    </table>
    </div>



STEP III: PLOTTING VARIOUS DISTRIBUTION PLOTS
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    sns.pairplot(iris)




.. parsed-literal::

    <seaborn.axisgrid.PairGrid at 0x2b2023b6648>




.. image:: output_7_1.png


.. code:: ipython3

    sns.heatmap(iris.corr(),cmap="BuPu",annot=True)




.. parsed-literal::

    <matplotlib.axes._subplots.AxesSubplot at 0x2b20395df08>




.. image:: output_8_1.png


STEP IV: FINDING OPTIMUM NUMBER OF CLUSTERS USING KMEANS CLASSIFICATION AND PLOTTING IT USING LINE GRAPH
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    # Finding the optimum number of clusters for k-means classification
    
    x = iris.iloc[:, [0, 1, 2, 3]].values
    
    from sklearn.cluster import KMeans
    wcss = []
    
    for i in range(1, 11):
        kmeans = KMeans(n_clusters = i, init = 'k-means++', 
                        max_iter = 300, n_init = 10, random_state = 0)
        kmeans.fit(x)
        wcss.append(kmeans.inertia_)

.. code:: ipython3

    # Plotting the results onto a line graph, 
    # `allowing us to observe 'The elbow'
    plt.plot(range(1, 11), wcss)
    plt.title('The elbow method')
    plt.xlabel('Number of clusters')
    plt.ylabel('WCSS') # Within cluster sum of squares
    plt.show()



.. image:: output_11_0.png


STEP V: IMPLEMENTING KMEANS CLUSTERING
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    # Applying kmeans to the dataset / Creating the kmeans classifier
    kmeans = KMeans(n_clusters = 3, init = 'k-means++',
                    max_iter = 300, n_init = 10, random_state = 0)
    y_kmeans = kmeans.fit_predict(x)
    # Visualising the clusters - On the first two columns
    plt.scatter(x[y_kmeans == 0, 0], x[y_kmeans == 0, 1], 
                s = 100, c = 'deepskyblue', label = 'Iris-setosa')
    plt.scatter(x[y_kmeans == 1, 0], x[y_kmeans == 1, 1], 
                s = 100, c = 'purple', label = 'Iris-versicolour')
    plt.scatter(x[y_kmeans == 2, 0], x[y_kmeans == 2, 1],
                s = 100, c = 'green', label = 'Iris-virginica')
    
    # Plotting the centroids of the clusters
    plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:,1], 
                s = 100, c = 'red', label = 'Centroids')
    
    plt.legend()




.. parsed-literal::

    <matplotlib.legend.Legend at 0x2b204a5d2c8>




.. image:: output_13_1.png

