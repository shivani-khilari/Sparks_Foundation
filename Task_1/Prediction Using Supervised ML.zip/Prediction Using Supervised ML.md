# 1:PREDICTION USING SUPERVISED ML

#### Simple Linear Regression (or SLR) is the simplest model in machine learning. It models the linear relationship between the independent and dependent variables.

#### In this project, there is one independent or input variable which represents the Sales data and is denoted by X. Similarly, there is one dependent or output variable which represents the Advertising data and is denoted by y. We want to build a linear relationship between these variables.

## THIS MODEL IS A SIMPLE LINEAR REGRESSION INVOLVING TWO VARIABLE
## OVERVIEW: Prediction of the percentage of marks of a student based on the number of Study Hours

### STEP I: IMPORTING REQUIRED LIBRARIES FOR FURTHER USE


```python
#Importing Required Libraries
import pandas as pd
import numpy as np 
import seaborn as sns
import matplotlib.pyplot as plt  
%matplotlib inline
```

### STEP II: IMPORTING THE DATASET FROM THE GIVEN LINK


```python
#Importing Dataset From The Given Link And Displaying It
data=pd.read_csv("http://bit.ly/w-data")
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.5</td>
      <td>21</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.1</td>
      <td>47</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.2</td>
      <td>27</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8.5</td>
      <td>75</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3.5</td>
      <td>30</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1.5</td>
      <td>20</td>
    </tr>
    <tr>
      <th>6</th>
      <td>9.2</td>
      <td>88</td>
    </tr>
    <tr>
      <th>7</th>
      <td>5.5</td>
      <td>60</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8.3</td>
      <td>81</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2.7</td>
      <td>25</td>
    </tr>
    <tr>
      <th>10</th>
      <td>7.7</td>
      <td>85</td>
    </tr>
    <tr>
      <th>11</th>
      <td>5.9</td>
      <td>62</td>
    </tr>
    <tr>
      <th>12</th>
      <td>4.5</td>
      <td>41</td>
    </tr>
    <tr>
      <th>13</th>
      <td>3.3</td>
      <td>42</td>
    </tr>
    <tr>
      <th>14</th>
      <td>1.1</td>
      <td>17</td>
    </tr>
    <tr>
      <th>15</th>
      <td>8.9</td>
      <td>95</td>
    </tr>
    <tr>
      <th>16</th>
      <td>2.5</td>
      <td>30</td>
    </tr>
    <tr>
      <th>17</th>
      <td>1.9</td>
      <td>24</td>
    </tr>
    <tr>
      <th>18</th>
      <td>6.1</td>
      <td>67</td>
    </tr>
    <tr>
      <th>19</th>
      <td>7.4</td>
      <td>69</td>
    </tr>
    <tr>
      <th>20</th>
      <td>2.7</td>
      <td>30</td>
    </tr>
    <tr>
      <th>21</th>
      <td>4.8</td>
      <td>54</td>
    </tr>
    <tr>
      <th>22</th>
      <td>3.8</td>
      <td>35</td>
    </tr>
    <tr>
      <th>23</th>
      <td>6.9</td>
      <td>76</td>
    </tr>
    <tr>
      <th>24</th>
      <td>7.8</td>
      <td>86</td>
    </tr>
  </tbody>
</table>
</div>



### STEP III: PLOTTING A SCATTERPLOT & HEATMAP TO CHECK THE CORELATION BETWEEN THE GIVEN VARIABLES


```python
#Scatterplot Of Hours VS Scores
data.plot(x='Hours',y='Scores',style='o')
plt.title("Scores vs Hours")
plt.xlabel("Scores")
plt.ylabel("Hours")
plt.show()
```


![png](output_5_0.png)



```python

```


```python
#HeatMap To Generate Correlation
sns.heatmap(data.corr(),cmap="BuPu")
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1d11de44c88>




![png](output_7_1.png)


### STEP IV: AS WE NEED TO WORK WITH ONE VARIABLE WE RESHAPE THE DATA


```python
#Reshaping The Data
X = data.iloc[:, :-1].values  
y = data.iloc[:, 1].values  
X=X.reshape(-1,1)
```

### STEP V: SPLITTING THE DATASET FOR TRAINING AND TESTING


```python
#Splitting The Dataset
from sklearn.model_selection import train_test_split  
X_train, X_test, y_train, y_test = train_test_split(X, y, 
                            test_size=0.2, random_state=0) 
```

### STEP VI: TRAINING THE ALGORITHM


```python
#Training The DataSet
from sklearn.linear_model import LinearRegression  
regressor = LinearRegression()  
regressor.fit(X_train,y_train)
print("Process Of Training Dataset Completed!!")
```

    Process Of Training Dataset Completed!!
    


```python
# Plotting The Regression Line
a = regressor.coef_
b = regressor.intercept_,
print(a)
print(b)
line = a*X+b

# Plotting Regression Line For Test Data
plt.scatter(X, y)
plt.plot(X, line);
plt.show()
```

    [9.91065648]
    (2.018160041434683,)
    


![png](output_14_1.png)


### STEP VII: PREDICTING THE SCORES


```python
#Predicting The Scores
print(X_test) 
y_pred = regressor.predict(X_test)
```

    [[1.5]
     [3.2]
     [7.4]
     [2.5]
     [5.9]]
    


```python
#Comparison Between Expected And Predicted Results
data = pd.DataFrame({'Actual': y_test, 'Predicted': y_pred,'Error':((y_test-y_pred)*100)/y_test})  
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Actual</th>
      <th>Predicted</th>
      <th>Error</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>20</td>
      <td>16.884145</td>
      <td>15.579276</td>
    </tr>
    <tr>
      <th>1</th>
      <td>27</td>
      <td>33.732261</td>
      <td>-24.934299</td>
    </tr>
    <tr>
      <th>2</th>
      <td>69</td>
      <td>75.357018</td>
      <td>-9.213070</td>
    </tr>
    <tr>
      <th>3</th>
      <td>30</td>
      <td>26.794801</td>
      <td>10.683996</td>
    </tr>
    <tr>
      <th>4</th>
      <td>62</td>
      <td>60.491033</td>
      <td>2.433817</td>
    </tr>
  </tbody>
</table>
</div>



### STEP VIII:PROJECTING THE SCORE FOR 9.25 HOURS/DAY STUDY


```python
#Predicting Score For 9.25 Hours/Day Study
print('For X = 9.25 hours Predicted Score:',regressor.predict([[9.25]]))
```

    For X = 9.25 hours Predicted Score: [93.69173249]
    

### STEP IX: CALCULATING THE ACCURACY


```python
#Caluculating Error
from sklearn import metrics
print('Mean Absolute Error:', 
      metrics.mean_absolute_error(y_test, y_pred))
```

    Mean Absolute Error: 4.183859899002975
    


```python
#Calculating R2 Score
from sklearn.metrics import r2_score
print ("R2 Score: {:.4f}".format(r2_score(y_test, y_pred)))
```

    R2 Score: 0.9455
    

###### AS SEEN FROM THE RESULTS OUR ACCURACY SCORE IS 94.55% FOR THE GIVEN MODEL


```python

```
